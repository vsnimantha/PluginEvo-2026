.. Copyright 2011-2018 David Malcolm <dmalcolm@redhat.com>
   Copyright 2011-2018 Red Hat, Inc.

   This is free software: you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful, but
   WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see
   <http://www.gnu.org/licenses/>.

Release Notes
=============

.. toctree::
   
   0.17.rst
   0.16.rst
   0.15.rst
   0.14.rst
   0.13.rst
   0.12.rst
   0.11.rst
   0.10.rst
   0.9.rst
   0.8.rst
   0.7.rst
